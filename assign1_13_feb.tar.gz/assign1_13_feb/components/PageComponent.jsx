import {Component} from 'react';
import React from 'react';
import ButtonComponent from './ButtonComponent.jsx';
import TextField from './TextField.jsx';


class PageComponent extends React.Component{
    
constructor(props){
    super(props);
    this.state={
        no_of_fields:0,
    };

}

handleClick=()=>{

   var  no=Number(this.state.no_of_fields)+1;
   
    this.setState({no_of_fields:no});
}



renderTextFields=()=>{
    var arr=[];
   // const elem=<TextField idDiv={}/>;

for(var i=1;i<=Number(this.state.no_of_fields);i++){

    arr.push(<TextField idDiv={i}/>);
    
}
return arr;

}

render(){
    
    return(
        <div><ButtonComponent handleClickProps={this.handleClick}/>
            {this.renderTextFields()}

        </div>
    

    );

}



}
export default PageComponent; 