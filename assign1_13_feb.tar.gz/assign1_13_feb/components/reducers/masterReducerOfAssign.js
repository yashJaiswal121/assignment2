import {ATTACH,REMOVE} from '../constants/constants';

const addReminder=(obj)=>{

    return {
       from:obj.from,
       to:obj.to,
    }
}

const delID=(state,obj)=>{

    const updatedState=state.filter(eachObj=>
            (eachObj.from!=obj.from)
    )

    return updatedState;
}
const masterReducerOfAssign =(state=[],action)=>{

    switch(action.type)
    {
        case ATTACH:
        return [...state,addReminder(action.payload)];

        case REMOVE:
        return delID(state,action.payload);
        default: return state;
    }

}

export default masterReducerOfAssign;
