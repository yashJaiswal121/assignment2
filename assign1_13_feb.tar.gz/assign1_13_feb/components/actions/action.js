import { ATTACH,REMOVE } from '../constants/constants';

export const attachAction =(obj)=>
{
    const action={
        type:ATTACH,
        payload:obj,
    };
    return action;

 }
 export const removeAction =(obj)=>
{
    const action={
        type:REMOVE,
        payload:obj,
    };
    return action;

 }
 